import UIKit
/*:
# Playground - Actividad 6
* Operadores personalizados
* Subscripts
* Control de errores

*/


/*: 
### Operadores personalizados
A) Crear el operador para realizar la potencia de el valor "a" a la potencia "b" en valores enteros
*/
postfix operator ^^
postfix func ^^(valor:Int)->Int
{
    //valor de b que se quiera poner
    let b = 2
    var z = b
    //asignamos el valor de la base a a
    let a = valor
    var tot = a
    repeat
    {
        tot = tot*a
        z = (z-1)
    } while (z>1)
    return tot
}
print(6^^)
//: B) Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor
/*
infix operator |>
func |> (a:Int, f:(Int)->Int) -> Int
{
    return f(a)
}

func ordenar1(dato:Int)->Int
{
    //operaciones para ordenar
    
    return ordenados
}
 /*
  let valoresmenor = valores.sorted()
  print (valoresmenor)
  */
 
+*/
var valores = [2,5,3,4]
valores.sort()
print(valores)

/*:
### Subscripts
A) Del conjunto de datos en el Array [2,3,4,5], crear el subscript para modificar los valores multiplicados por el valor 2 y extraer al valor dado un índice.
*/
let array = [2,3,4,5]
class multiplicacion
{
    var resultado:[Int]
    init(res:[Int])
    {
        self.resultado = res
    }
    subscript(idx:Int)->Int
    {
        //aqui es donde se hace la multiplicacion
        get
        {
            return resultado[idx]
        }
        set(newres)
        {
            resultado[idx] = newres * 2
        }
    }
}
let multi = multiplicacion(res:array)
multi[2] = multi[2]
multi.resultado
print("El valor de la segunda posicion multiplicada por 2 es de: ", multi[2])
//: B) Crear el Struct para definir u obtener la posición  para los personaje de tipo Enemigo donde cada posición es de tipo CGPoint aplicnado subscritps

/*struct CGPoint
{
    //init(from decoder:Decoder) throws
    //init (x:Double , y:Double)
    
}

//eh?
//cgpoint es un array 2d tipo estructura https://developer.apple.com/documentation/coregraphics/cgpoint
 
 */
/*:
### Control de Errores
A) Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de un colección ["A":1, "B":2,"C":3]
*/
let prueba = ["A":1, "B":2,"C":3]
func ExisteValor(idx:String)
{
    guard let existe = prueba[idx]
    else
    {
        print ("No existe")
        return
    }
    print ("Existe")
}
ExisteValor(idx: "Juan")
prueba["Juan"]







