import UIKit
/*:
# Playground - Actividad 4
* Condicionales y Ciclos
* Funciones
* Enumareción
*/



/*:
### Condicionales y Ciclos
A) Declarar la variable "datos" con los valores [3,6,9,2,4,1]
*/
var datos = [3,6,9,2,4,1]
print(datos)
//: B) realizar el recorrido de la variable "datos" con la instrucción "for"
for d in datos
{
    print(d)
}

//: C) Encontrar los valores menores a 5
print("numeros menores a 5: ")
for d in datos
{
    if d < 5{
        print(d)
    }
}

/*:
### Funciones
A) Crea la función "suma" que reciba dos parámetros de tipo entero regresando la suma de ambos números.
*/
func suma(a:Int,b:Int) -> Int
{
    return a+b
}
print (suma(a:8,b:1))
//: B) Crear la función "potencia" que reciba dos parámetros de tipo entero, el primer parámetro para el numero base y el segundo la potencia a elevar, regresando el resultado de la potencia.
func potencia(a:Int,b:Int) -> Int
{
    //contador
    var z = b
    var tot = a
    repeat
    {
        tot = tot*a
        z = (z-1)
    } while (z>1)
    return tot
}
print(potencia(a: 3, b: 4))
/*:
### Enumeraciones
A) Crea la enumaración "meses" para definir tipos de datos basados en los meses del año.
*/
enum meses
{
    case Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre
}

//: B) Crear la función "numeroMes" que reciba el tipo de dato "meses" y regrese el numero del mes correspondiente

func numeroMes(meses:String) -> String
{
    return meses
}


//: C) Para regresar el numero de mes correspondiente utilizar la "switch"
let mes:meses = .Febrero
switch mes
{
case .Enero:
    print("Enero es el mes:1")
case .Febrero:
    print("Febrero es el mes:2")
case .Marzo:
    print("Marzo es el mes:3")
case .Abril:
    print("Abril es el mes:4")
case .Mayo:
    print("Mayo es el mes:5")
case .Junio:
    print("Junio es el mes:6")
case .Julio:
    print("Julio es el mes:7")
case .Agosto:
    print("Agosto es el mes:8")
case .Septiembre:
    print("Septiembre es el mes:9")
case .Octubre:
    print("Octubre es el mes:10")
case .Noviembre:
    print("Noviembre es el mes:11")
case .Diciembre:
    print("Diciembre es el mes:12")
}


