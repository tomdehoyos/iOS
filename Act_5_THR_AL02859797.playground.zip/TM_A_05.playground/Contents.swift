import UIKit
/*:
# Playground - Actividad 5
* Class y Struct
* Extension
* Optional
*/


/*: 
### Actividad Class y Struct
A) Diseñar la clase Persona que contenga dos metodos, el primero "Saludar" que reciba el parámetro nombre y regrese el mensaje el nombre mas el texto "mucho gusto", el segundo metodo "Caminar" que reciba como parámetro un tipo de dato Int y regrese un tipo de dato String indicando el numero de pasos caminados.
*/
class persona
{
    var saludar = "default"
    var caminar = 0;
    func nombre()->String
        {
            return("Hola, mucho gusto \(saludar)")
        }
    func camina()->String
        {
            return("A caminado \(caminar) pasos")
        }
}
var subject = persona()
subject.saludar = "Tomás"
subject.caminar = 30
subject.nombre()
subject.caminar

//: B) Diseñar el struct "Pantalla" la cual recibirá como como parametros el ancho y alto de una pantalla como tipo de datos Int con un constructor, para inicializar la estructura.
struct pantalla
{
    var ancho:Int
    var alto:Int
    
}

/*:
### Extensions
A) Diseñar un extensión del tipo de dato Int que represente las horas y que pueda regresar los segundos correspondientes (puedes utilizar una función o una variable computada)
*/
extension Int
{
    var horas:Int
    {
        return self*1
    }
    var segundos:Int
    {
        return self*1440
    }
}
let hora = 24.horas
let segundos = 60.segundos
print("Un dia equivale a \(hora) horas")
print("24 horas tienen \(segundos) segundos")
//: B) Diseñar una extensión del tipo de dato String que represente un día de la semana y regrese el numero correspondiente iniciando con Domingo = 1 y finalizando Sábado = 7
extension String
{
    var Lunes:String
    {
        return "Lunes = 2"
    }
    var Martes:String
    {
        return "Martes = 3"
    }
    var  Miercoles:String
    {
        return "Miercoles = 4"
    }
    var Jueves:String
    {
        return "Jueves  = 5"
    }
    var Viernes:String
    {
        return "Viernes = 6"
    }
    var Sabado:String
    {
        return "Sabado = 7"
    }
    var Domingo:String
    {
        return "Domingo = 1"
    }
}
let d1 = "".Domingo
let d2 = "".Lunes
let d3 = "".Martes
let d4 = "".Miercoles
let d5 = "".Jueves
let d6 = "".Viernes
let d7 = "".Sabado
print ("El dia \(d2)")

/*:
### Optionals
A) Diseñar una variable optional para recibir el tipo de dato Int en caso de que exista.
*/
let numeros = ["1":1,"2":2,"3":3]
var numero:Int?
numero = numeros ["4"]
if numeros["4"] != nil
{
    print("Existe")
}
else
{
    print("No existe")
}
//: B) Para la colección let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200] diseñar una variable opcional para recibir el valor de dias["DF"]
let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200]
var dia:Int?
if dias ["DF"] != nil
{
    print("Existe")
}
else
{
    print("No existe")
}




