import UIKit
/*:
# Playground - Actividad 7
* Valor por tipo y por referencia
* Funciones personalizadas Y Genericos
* Funciones de la biblioteca Swift para Arreglos
*/


/*: 
### Valor por tipo y por referencia
A) Para la colección "var costo_referencia:[Float] = [8.3,10.5,9.9]", aplicar el impuesto del 16% a través de recorrer la colección "costo_referencia" para aplicar el impuesto a cada cantidad, crear una función Impuesto que recibe como parámetro la colección y regrese aplicado el impuesto a cada cantidad.
*/
var costo_referencia:[Float] = [8.3,10.5,9.9]
func Impuesto(arreglo:[Float]) -> [Float]
{
    var res:[Float] = []
    for i in arreglo
    {
        res.append(i*1.16)
    }
    return res
}
print("Los impuestos son: \(Impuesto(arreglo:costo_referencia))")
//: B) Crear la función "sumaTres"  que reciba una función con dos valores a sumar y un segundo parametro para sumar el tercer número.
func sumaDos(a:Float,b:Float) -> Float
{
    var res1:Float=0
    res1 = a+b
    return res1
}
func SumaTres(c:Float, d:Float ) ->Float
{
    var res2:Float=0
    res2=c+d
    return res2
}
print("La suma de los tres numeros es de: \(SumaTres(c: sumaDos(a: 5.3, b: 6.1), d: 9.1))")
/*:
### Funciones personalizadas y Genéricos

 
 A) Generics: Crear la función genérica para intercambiar valores entre dos variables del mismo tipo.
*/
//https://docs.swift.org/swift-book/LanguageGuide/Generics.html
//el inout es para poder meter variables no definidas y no tener que devolver nada y al parecer no tener que usar los temp
func cambiar2<T>(_ a: inout T, _ b: inout T)
{
    let cambio = a
    a = b
    b = cambio
    
}
var test1 = 43
var test2 = 12
//el & es necesario por el inout
cambiar2(&test1, &test2)
print(test1)
print(test2)
//: B) Función personalizada: Crear la función "Transformar" que reciba como parámetro una colección de tipo Int  "var datos = [3,7,9,2]" y una función que transforme cada valor de la coleción en una operación definida fuera de la función, regresando una colección transformada.
//no entendi
extension Array
{
    func Transformar<T> (inicial:T, acumula:(T, Element) -> T ) -> T
    {
        var respuesta:T = inicial
        for valor in self
        {
            respuesta = acumula(respuesta, valor)
        }
        return respuesta
    }
}
var datos = [3,7,9,2,]
var letras = ["a","b","c","d"]
datos.Transformar(inicial: 0) {(a,b) in a + b}
letras.Transformar(inicial: "") {(a,b) in a + b}
print(datos)
/*:
### Biblioteca de Swift
A) Aplicar la función de librería de Swift "map" para la colección var precios = [4.2, 5.3, 8.2, 4.5] y aplicar el impuesto de 16% y asignarla a la variable "impuesto"
*/
var precios = [4.2, 5.3, 8.2, 4.5]
var impuestos = precios.map
{
    a in return a*1.16
}
impuestos
//: B) Aplicar la función de la librería de Swift "filter" para la colección resultante "impuesto" del paso A, en donde se obtengas solo los precios mayores a 6.0 y asignarlos a la variable "precio_menor"
var precio_menor = impuestos.filter
{
    a in a>6.0
}
precio_menor





