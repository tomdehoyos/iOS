import UIKit
/*:
# Playground - Actividad 3
* Tipos de datos
* Asociación de tipos
* Arreglos y Diccionarios
*/


/*: 
### Actividad de Tipos de datos
A) Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida
*/
var entero = 1 //implicita damos por hecho el tipo de variable
let entero2:Int=4 //explicita estamos declarando el tipo de variable

var decimal = 3.1416
let decimal2:Double = 3.1416

var decimalF = 1.23456789
let decimalF2:Float = 1.23456789

var palabra = "Tomas"
let palabra2:String = "Tomas"

var white = true
let white2:Bool = true

var black = false
let black2:Bool = false
/*:
### Asociación de tipos
A) Declara el tipo de dato por asociación para un tipo de dato String
*/
var ejemplo:String="valor asociado"

//esto es con coordenadas?
//: B) Declara el tipo de dato por asociación para un tipo de dato  Número entero.
var ejemplonum:Int=1


/*: 
### Arreglos y Diccionarios
A) Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10.
*/
var numeros:Array<Int> = [1,2,3,4,5,6,7,8,9,10]
print(numeros)
var numerosA = [1,2,3,4,5,6,7,8,9,10]
print(numerosA)

//: B) Crea la variable "diasSemana" de tipo Dictionary con la relación numero:día Ej. 1:"Lunes"
var diasSemana:Dictionary<Int, String> = [1:"Lunes", 2:"Martes", 3:"Miercoles", 4:"Jueves", 5:"Viernes", 6:"Sabado", 7:"Domingo"]
print("Semana \(diasSemana)")

/*:
### Condicionales y Ciclos
A) Declarar la variable "datos" con los valores [3,6,9,2,4,1]
*/
var datos = [3,6,9,2,4,1]
//: B) realizar el recorrido de la variable "datos" con la instrucción "for"
for d in datos
{
 print(d)
}


//: C) Encontrar los valores menores a 5
print("numeros menores a 5: ")
for d in datos
{
    if d < 5{
        print(d)
    }
 print(d)
}



